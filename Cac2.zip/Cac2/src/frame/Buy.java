package frame;

import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.DefaultCellEditor;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import frame.Shoppingcart.ButtonEditor;
import frame.Shoppingcart.ButtonRenderer;

public class Buy extends JFrame {

	private JPanel contentPane;
	  private JTable table;
	  Connection connection = dbconnection.getConnection();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Buy frame = new Buy();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Buy() {
		int totamt=0;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1645,1078);//Full Screen
		contentPane = new JPanel();
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		 String[] columns = {"Item ID", "Item Name", "Category", "Price"};
	        ArrayList<Object[]> rowData = new ArrayList<>();
	        
	        try {
				 java.sql.Statement statement = connection.createStatement();
				  ResultSet resultSet = statement.executeQuery("SELECT a.product_id, b.name, b.category, a.id, a.amt FROM cart a INNER JOIN product b ON a.product_id=b.id WHERE a.user_id = '"+globals.SESSION_USERID+"'");
	                    while (resultSet.next()) {
					 
					 int pid = resultSet.getInt("id");
					 String pname = resultSet.getString("name");
					 String pcat = resultSet.getString("category");
					 int pamt = resultSet.getInt("amt");
					 
					 totamt=totamt+pamt;
					 
					 rowData.add(new Object[]{pid, pname, pcat, pamt});
					
		
				      
					
					}
	                    
		        } catch (SQLException e1) {
		            e1.printStackTrace();
		        }
	        
	        
	        Object[][] data = rowData.toArray(new Object[0][]);
	        DefaultTableModel model = new DefaultTableModel(data, columns);

	        table = new JTable(model);
	        

	        JScrollPane scrollPane = new JScrollPane(table);
	        scrollPane.setBounds(10, 240, 520, 451);
	        contentPane.add(scrollPane);
	        
	        ImageIcon imageIcon1 = new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\buy.jpg");
         Image image1 = imageIcon1.getImage(); // transform it

         Image newimg1 = image1.getScaledInstance(1553, 870, java.awt.Image.SCALE_SMOOTH); // scale it the smooth way

         imageIcon1 = new ImageIcon(newimg1);
         
         JLabel lblNewLabel_3 = new JLabel("");
         lblNewLabel_3.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\sas.png"));
         lblNewLabel_3.setBounds(0, 20, 287, 70);
         contentPane.add(lblNewLabel_3);
         
         JButton btnNewUser = new JButton("HOME");
         btnNewUser.addActionListener(new ActionListener() {
         	public void actionPerformed(ActionEvent e) {
         		Main e1 =new Main();
 				e1.show();
 				dispose();
         	}
         });
         btnNewUser.setForeground(new Color(0, 204, 255));
         btnNewUser.setFont(new Font("Javanese Text", Font.BOLD, 15));
         btnNewUser.setBackground(new Color(53, 19, 107));
         btnNewUser.setBounds(10, 725, 117, 29);
         contentPane.add(btnNewUser);
         
         JButton btnNewUser_1 = new JButton("CONFIRM");
         btnNewUser_1.addActionListener(new ActionListener() {
         	public void actionPerformed(ActionEvent e) {
         		Purchase b1 =new Purchase();
 				b1.show();
 				dispose();
         	}
         });
         btnNewUser_1.setForeground(new Color(0, 204, 255));
         btnNewUser_1.setFont(new Font("Javanese Text", Font.BOLD, 15));
         btnNewUser_1.setBackground(new Color(53, 19, 107));
         btnNewUser_1.setBounds(383, 725, 147, 29);
         contentPane.add(btnNewUser_1);
         
         JLabel lblCartSummary = new JLabel("CART SUMMARY");
         lblCartSummary.setFont(new Font("Microsoft Himalaya", Font.BOLD, 40));
         lblCartSummary.setBounds(146, 152, 240, 78);
         contentPane.add(lblCartSummary);
         
         JLabel bg = new JLabel("");
         bg.setForeground(new Color(0, 0, 0));
         bg.setIcon(imageIcon1);
         bg.setBounds(0, 0, 1553, 845);
         contentPane.add(bg);
         

	        table = new JTable(model);
	      
	        
	 }

  

  
    }

	
	

