package frame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JScrollBar;
import java.awt.Panel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Readingglass extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Readingglass frame = new Readingglass();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Readingglass() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1645,1078);//Full Screen
		contentPane = new JPanel();
		SqlQueries sqlFunctions = new SqlQueries();
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 1159, 206);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("<html><pre>Discover the luxury of internationally appealing, premium designs with John Jacobs\r\nCollections. These bring back iconic elements from history and merge them together with \r\nthe modish craftsmanship of today to get the very best on your eyes. Experience the \r\nopulence of owning a style statement with its most popular collections.</html></pre>");
		lblNewLabel_1.setBounds(603, 35, 529, 138);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\name1.png"));
		lblNewLabel_2.setBounds(30, 35, 516, 138);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\nav.png"));
		lblNewLabel.setBounds(1158, 0, 382, 206);
		contentPane.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(204, 204, 255));
		panel_1.setBounds(0, 208, 1540, 637);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JPanel panel_1_1_1_1_1 = new JPanel();
		panel_1_1_1_1_1.setLayout(null);
		panel_1_1_1_1_1.setBackground(Color.WHITE);
		panel_1_1_1_1_1.setBounds(33, 87, 336, 317);
		panel_1.add(panel_1_1_1_1_1);
		
		JLabel lblNewLabel_3_2_3_1_1_1 = new JLabel("");
		lblNewLabel_3_2_3_1_1_1.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\read1.jpg"));
		lblNewLabel_3_2_3_1_1_1.setBounds(28, 79, 257, 109);
		panel_1_1_1_1_1.add(lblNewLabel_3_2_3_1_1_1);
		
		JLabel lblNewLabel_4_1_3_1_1_1 = new JLabel("<html><pre>Nerdlane\r\nBrown Full Frame Wayfarer Reading Glasses\r\n\r\nRs.999</html></pre>");
		lblNewLabel_4_1_3_1_1_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_1_1_1.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_1_1_1.setBounds(28, 196, 257, 90);
		panel_1_1_1_1_1.add(lblNewLabel_4_1_3_1_1_1);
		
		JButton btnAddToCart_1_1_1 = new JButton("Add to Cart");
		btnAddToCart_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("54",999);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart_1_1_1.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_1_1_1.setBackground(new Color(0, 153, 255));
		btnAddToCart_1_1_1.setBounds(107, 296, 85, 21);
		panel_1_1_1_1_1.add(btnAddToCart_1_1_1);
		
		JPanel panel_1_1_1_1 = new JPanel();
		panel_1_1_1_1.setLayout(null);
		panel_1_1_1_1.setBackground(Color.WHITE);
		panel_1_1_1_1.setBounds(408, 87, 336, 317);
		panel_1.add(panel_1_1_1_1);
		
		JLabel lblNewLabel_3_2_3_1_1 = new JLabel("");
		lblNewLabel_3_2_3_1_1.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\read2.jpg"));
		lblNewLabel_3_2_3_1_1.setBounds(28, 79, 257, 109);
		panel_1_1_1_1.add(lblNewLabel_3_2_3_1_1);
		
		JLabel lblNewLabel_4_1_3_1_1 = new JLabel("<html><pre>Nerdlane\r\nBlack Full Frame Wayfarer Reading Glasses\r\n\r\nRs.999</html></pre>");
		lblNewLabel_4_1_3_1_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_1_1.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_1_1.setBounds(28, 196, 257, 90);
		panel_1_1_1_1.add(lblNewLabel_4_1_3_1_1);
		
		JButton btnAddToCart_1_1 = new JButton("Add to Cart");
		btnAddToCart_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("55",999);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart_1_1.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_1_1.setBackground(new Color(0, 153, 255));
		btnAddToCart_1_1.setBounds(126, 296, 85, 21);
		panel_1_1_1_1.add(btnAddToCart_1_1);
		
		JPanel panel_1_1_1_1_2 = new JPanel();
		panel_1_1_1_1_2.setLayout(null);
		panel_1_1_1_1_2.setBackground(Color.WHITE);
		panel_1_1_1_1_2.setBounds(790, 87, 336, 317);
		panel_1.add(panel_1_1_1_1_2);
		
		JLabel lblNewLabel_3_2_3_1_1_2 = new JLabel("");
		lblNewLabel_3_2_3_1_1_2.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\read3.jpg"));
		lblNewLabel_3_2_3_1_1_2.setBounds(28, 79, 257, 109);
		panel_1_1_1_1_2.add(lblNewLabel_3_2_3_1_1_2);
		
		JLabel lblNewLabel_4_1_3_1_1_2 = new JLabel("<html><pre>Nerdlane\r\nBlack Full Frame Rectangle Reading Glasses\r\n\r\nRs.999</html></pre>");
		lblNewLabel_4_1_3_1_1_2.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_1_1_2.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_1_1_2.setBounds(28, 196, 257, 90);
		panel_1_1_1_1_2.add(lblNewLabel_4_1_3_1_1_2);
		
		JButton btnAddToCart_1_1_2 = new JButton("Add to Cart");
		btnAddToCart_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("56",999);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart_1_1_2.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_1_1_2.setBackground(new Color(0, 153, 255));
		btnAddToCart_1_1_2.setBounds(131, 296, 85, 21);
		panel_1_1_1_1_2.add(btnAddToCart_1_1_2);
		
		JPanel panel_1_1_1_1_3 = new JPanel();
		panel_1_1_1_1_3.setLayout(null);
		panel_1_1_1_1_3.setBackground(Color.WHITE);
		panel_1_1_1_1_3.setBounds(1157, 87, 336, 317);
		panel_1.add(panel_1_1_1_1_3);
		
		JLabel lblNewLabel_3_2_3_1_1_3 = new JLabel("");
		lblNewLabel_3_2_3_1_1_3.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\read4.jpg"));
		lblNewLabel_3_2_3_1_1_3.setBounds(41, 83, 257, 109);
		panel_1_1_1_1_3.add(lblNewLabel_3_2_3_1_1_3);
		
		JLabel lblNewLabel_4_1_3_1_1_3 = new JLabel("<html><pre>Alf\r\nBlack Tinted Prescription Readinglasses\r\n\r\nRs.999</html></pre>");
		lblNewLabel_4_1_3_1_1_3.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_1_1_3.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_1_1_3.setBounds(28, 196, 257, 90);
		panel_1_1_1_1_3.add(lblNewLabel_4_1_3_1_1_3);
		
		JButton btnAddToCart_1_1_3 = new JButton("Add to Cart");
		btnAddToCart_1_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("57",999);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		
		});
		btnAddToCart_1_1_3.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_1_1_3.setBackground(new Color(0, 153, 255));
		btnAddToCart_1_1_3.setBounds(129, 296, 85, 21);
		panel_1_1_1_1_3.add(btnAddToCart_1_1_3);
		
		JButton btnNewButton = new JButton("2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Readingglass2 eg2 = new Readingglass2();
				eg2.show();	
				dispose();
			}
		});
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.setBackground(new Color(0, 153, 255));
		btnNewButton.setBounds(716, 494, 114, 40);
		panel_1.add(btnNewButton);
		
		Panel panel_2 = new Panel();
		panel_2.setLayout(null);
		panel_2.setBackground(new Color(0, 102, 204));
		panel_2.setBounds(0, 597, 1540, 40);
		panel_1.add(panel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Copyright © 2023. All Rights Reserved");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setBounds(657, 10, 251, 25);
		panel_2.add(lblNewLabel_3);
		
		JButton btnReadingGlasses = new JButton("Home");
		btnReadingGlasses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main m1 =new Main(); //next page
				m1.show(); //next page
				dispose(); //next page
			}
		});
		btnReadingGlasses.setFont(new Font("Sitka Heading", Font.BOLD, 13));
		btnReadingGlasses.setBackground(new Color(0, 153, 255));
		btnReadingGlasses.setBounds(676, 10, 154, 21);
		panel_1.add(btnReadingGlasses);
		
	
	}

}
