package frame;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;

public class Login extends JFrame {

    private JPanel contentPane;
    private JTextField loginEmailField;
    private JPasswordField loginPasswordField;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Login frame = new Login();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Login() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1645,1078);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(255, 255, 255));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
                                                       
                                                        JPanel panel_1 = new JPanel();
                                                        panel_1.setForeground(new Color(53, 19, 107));
                                                        panel_1.setBackground(new Color(102, 153, 255));
                                                        panel_1.setBounds(406, 163, 674, 282);
                                                        contentPane.add(panel_1);
                                                        panel_1.setLayout(null);
                                                       
                                                        JLabel lblNewLabel = new JLabel("LOGIN");
                                                        lblNewLabel.setForeground(new Color(255, 255, 255));
                                                        lblNewLabel.setBounds(296, 27, 107, 29);
                                                        panel_1.add(lblNewLabel);
                                                        lblNewLabel.setFont(new Font("Microsoft Himalaya", Font.BOLD, 32));
                                                       
                                                                JLabel loginEmailLabel = new JLabel("User Name");
                                                                loginEmailLabel.setForeground(new Color(255, 255, 255));
                                                                loginEmailLabel.setBounds(30, 84, 132, 29);
                                                                panel_1.add(loginEmailLabel);
                                                                loginEmailLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 20));
                                                               
                                                                        loginEmailField = new JTextField();
                                                                        loginEmailField.setBounds(152, 87, 168, 26);
                                                                        panel_1.add(loginEmailField);
                                                                        loginEmailField.setColumns(10);
                                                                       
                                                                                JLabel loginPasswordLabel = new JLabel("Password");
                                                                                loginPasswordLabel.setForeground(new Color(255, 255, 255));
                                                                                loginPasswordLabel.setBounds(362, 84, 107, 29);
                                                                                panel_1.add(loginPasswordLabel);
                                                                                loginPasswordLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 20));
                                                                               
                                                                                        loginPasswordField = new JPasswordField();
                                                                                        loginPasswordField.setBounds(463, 87, 174, 26);
                                                                                        panel_1.add(loginPasswordField);
                                                                                       
                                                                                                JButton loginButton = new JButton("Login");
                                                                                                loginButton.setForeground(new Color(0, 0, 0));
                                                                                                loginButton.setBackground(new Color(102, 153, 255));
                                                                                                loginButton.setBounds(279, 158, 117, 29);
                                                                                                panel_1.add(loginButton);
                                                                                                loginButton.setFont(new Font("Javanese Text", Font.BOLD, 15));
                                                                                               
                                                                                                JButton btnNewUser = new JButton("New User");
                                                                                                btnNewUser.setForeground(new Color(0, 204, 255));
                                                                                                btnNewUser.setBounds(279, 231, 117, 29);
                                                                                                panel_1.add(btnNewUser);
                                                                                                btnNewUser.setBackground(new Color(53, 19, 107));
                                                                                                btnNewUser.addActionListener(new ActionListener() {
                                                                                                public void actionPerformed(ActionEvent e) {
                                                                                                Registration second = new Registration();  
//                                                                                         second.index1=0;
                                                                                               setVisible(false); // Hide current frame
                                                                                               second.setVisible(true); //second frame
                                                                                                }
                                                                                                });
                                                                                                btnNewUser.setFont(new Font("Javanese Text", Font.BOLD, 15));
                                                                                                
                                                                                                JLabel lblNewLabel_1 = new JLabel("Don't have account? Create New Account");
                                                                                                lblNewLabel_1.setFont(new Font("Tahoma", Font.ITALIC, 13));
                                                                                                lblNewLabel_1.setBounds(211, 206, 317, 15);
                                                                                                panel_1.add(lblNewLabel_1);
                                                                                                
                                                                                                ImageIcon imageIcon1 = new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\bg.jpg");
                                                                                                Image image1 = imageIcon1.getImage(); // transform it

                                                                                                Image newimg1 = image1.getScaledInstance(1553, 870, java.awt.Image.SCALE_SMOOTH); // scale it the smooth way

                                                                                                imageIcon1 = new ImageIcon(newimg1);
                                                                                                
                                                                                                JLabel lblNewLabel_3 = new JLabel("");
                                                                                                lblNewLabel_3.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\sas.png"));
                                                                                                lblNewLabel_3.setBounds(0, 20, 318, 70);
                                                                                                contentPane.add(lblNewLabel_3);
                                                                                                
                                                                                                JLabel bg = new JLabel("");
                                                                                                bg.setIcon(imageIcon1);
                                                                                                bg.setBounds(0, 0, 1553, 845);
                                                                                                contentPane.add(bg);
                                                                                                loginButton.addActionListener(new ActionListener() {
                                                                                                    public void actionPerformed(ActionEvent e) {
                                                                                                        String email = loginEmailField.getText();
                                                                                                        String password = String.valueOf(loginPasswordField.getPassword()            );
                                                                                                        login(email, password);
                                                                                                    }
                                                                                                });
    }

   

    private void login(String uname, String pass) {
        String query = "SELECT * FROM users WHERE uname = ? AND pass = ?";
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sasFrames", "root", "");
                PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, uname);
            statement.setString(2, pass);
            ResultSet result = statement.executeQuery();
            if (result.next()) {
            	globals.SESSION_USERID = result.getString("id");
                JOptionPane.showMessageDialog(contentPane, "Login successful!");
                Main second = new Main();  
                second.show();
                dispose();
       //setVisible(false); // Hide current frame
       //second.getItems(cart,index);
       //second.setVisible(true); //second frame
            } else {
            loginEmailField.setText("");
            loginPasswordField.setText("");
         
                JOptionPane.showMessageDialog(contentPane, "Invalid Username or Password/ If you are a New user, REGISTER!!!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}