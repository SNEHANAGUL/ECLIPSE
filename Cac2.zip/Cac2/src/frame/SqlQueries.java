package frame;

import java.sql.*;

import javax.swing.JDialog;

import frame.globals;

public class SqlQueries {
	int status=0;
	Connection connection = dbconnection.getConnection();
	public void insertCartItem(String pid,int amt) {
		
		try {
		    Connection connection = dbconnection.getConnection();
		    ResultSet resultSet = connection.createStatement().executeQuery("select * from cart where user_id = '"+globals.SESSION_USERID+"' and product_id = "+pid);
		    while (resultSet.next()) {
		    	status=1;
		        int qty = resultSet.getInt("qty");
		        int totamt = resultSet.getInt("amt");
		        qty = qty + 1;
		        totamt = totamt + amt;

		        Statement updateStatement = connection.createStatement();
		        int rowsAffected = updateStatement.executeUpdate("update cart set qty='" + qty + "',amt='" + totamt + "' where  user_id = '" + globals.SESSION_USERID + "' and product_id = " + pid);
		      
		       
		    }
		    if (status==0) {
		        Statement insertStatement = connection.createStatement();
		        int rowsAffected = insertStatement.executeUpdate("insert into cart (product_id,user_id,qty,amt) values ('" + pid + "','" + globals.SESSION_USERID + "','1','" + amt + "')");
		       
		    }
		  
		} catch (SQLException e1) {
		    e1.printStackTrace();
		}
		
		
		
		
		
		}
	
	
	
	
	
	
	
//	public ResultSet displayCartItems() {
//		try {
//			getConnection();
//			String sql1="SELECT * FROM cart";
//			try {
//				rs=stmt.executeQuery(sql1);
//				while(rs.next()) {
//					System.out.println(rs.getString(1));
//				}
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//		catch(Exception e) {
//			e.printStackTrace();
//		}
//		finally {
//			
//			System.out.print("done");
//		}
//		return rs;
//	}
	public void updateQuantity(int id) {
		Connection connection = dbconnection.getConnection();
		Statement stmt=null;
		String sql="UPDATE cart set qty=qty-1 where id='"+id+"'";
		try {
			stmt=connection.createStatement();
			stmt.executeUpdate(sql);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public int deleteCartItem(int id) {
		Connection connection = dbconnection.getConnection();
		Statement stmt=null;
		String check="SELECT qty from cart where id='"+id+"'";
		try {
			stmt=connection.createStatement();
			ResultSet rs=stmt.executeQuery(check);
			while(rs.next()) {
				//System.out.printf("\nkk  ",rs);
				int q=rs.getInt(1);
				//System.out.println(q);
				//System.out.print(q);
				if(q>1) {
					updateQuantity(id);
					return 1;
				}
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sql="DELETE FROM cart where product_id='"+id+"'";
		try {
			stmt.executeUpdate(sql);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return 0;
	}


}
