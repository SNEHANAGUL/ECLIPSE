package frame;

import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.ImageIcon;

public class Thankyou extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Thankyou frame = new Thankyou();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Thankyou() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1645,1080);//Full Screen
		contentPane = new JPanel();
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//JLabel lblNewLabel = new JLabel("");
		//lblNewLabel.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\tq.jpg"));
		//lblNewLabel.setBounds(0, 0, 1540, 845);
		//contentPane.add(lblNewLabel);
		ImageIcon imageIcon1 = new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\Thankyou.png");
        Image image1 = imageIcon1.getImage(); // transform it

        Image newimg1 = image1.getScaledInstance(1553, 870, java.awt.Image.SCALE_SMOOTH); // scale it the smooth way

        imageIcon1 = new ImageIcon(newimg1);
    
        

        JLabel bg = new JLabel("");
        bg.setIcon(imageIcon1);
        bg.setBounds(0, 0, 1553, 845);
        contentPane.add(bg);
		
	}
}
