package frame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JScrollBar;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Panel;

public class Sunglass1 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Sunglass1 frame = new Sunglass1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Sunglass1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1645,1078);//Full Screen
		contentPane = new JPanel();
		SqlQueries sqlFunctions = new SqlQueries();
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 1172, 178);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\name1.png"));
		lblNewLabel.setBounds(22, 23, 518, 143);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("<html><pre>Discover the luxury of internationally appealing, premium designs with John Jacobs\r\nCollections. These bring back iconic elements from history and merge them together with \r\nthe modish craftsmanship of today to get the very best on your eyes. Experience the \r\nopulence of owning a style statement with its most popular collections.</html></pre>");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel_2.setBounds(560, 55, 532, 88);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\nav.png"));
		lblNewLabel_1.setBounds(1171, 0, 359, 178);
		contentPane.add(lblNewLabel_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(204, 204, 255));
		panel_1.setBounds(0, 175, 1090, 1550);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setLayout(null);
		panel_1_1.setBackground(Color.WHITE);
		panel_1_1.setBounds(10, 123, 336, 362);
		panel_1.add(panel_1_1);
		
		JLabel lblNewLabel_3_2_3 = new JLabel("");
		lblNewLabel_3_2_3.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\sun1.png"));
		lblNewLabel_3_2_3.setBounds(28, 77, 257, 109);
		panel_1_1.add(lblNewLabel_3_2_3);
		
		JLabel lblNewLabel_4_1_3 = new JLabel("<html><pre>Fastrack\r\nFastrack Black Tinted Round Sunglasses\r\n\r\nRs.2290</html></pre>");
		lblNewLabel_4_1_3.setForeground(Color.BLACK);
		lblNewLabel_4_1_3.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3.setBounds(28, 196, 257, 116);
		panel_1_1.add(lblNewLabel_4_1_3);
		
		JButton btnAddToCart = new JButton("Add to Cart");
			btnAddToCart.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(globals.SESSION_USERID!="")
					{
						sqlFunctions.insertCartItem("8",2290);
						JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
					}
					else
					{
						JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
						 Login second = new Login();  
			                second.show();
			                dispose();
					}
					
				}
		});
		btnAddToCart.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart.setBackground(new Color(0, 153, 255));
		btnAddToCart.setBounds(107, 341, 85, 21);
		panel_1_1.add(btnAddToCart);
		
		JPanel panel_1_2 = new JPanel();
		panel_1_2.setLayout(null);
		panel_1_2.setBackground(Color.WHITE);
		panel_1_2.setBounds(387, 123, 336, 362);
		panel_1.add(panel_1_2);
		
		JLabel lblNewLabel_3_2_3_1 = new JLabel("");
		lblNewLabel_3_2_3_1.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\sun2.jpg"));
		lblNewLabel_3_2_3_1.setBounds(47, 77, 238, 109);
		panel_1_2.add(lblNewLabel_3_2_3_1);
		
		JLabel lblNewLabel_4_1_3_1 = new JLabel("<html><pre>Siognee\r\nPink Tinted Hexagon Sun Glass\r\n\r\nRs.990</html></pre>");
		lblNewLabel_4_1_3_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_1.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_1.setBounds(30, 196, 255, 117);
		panel_1_2.add(lblNewLabel_4_1_3_1);
		
		JButton btnAddToCart_1 = new JButton("Add to Cart");
		btnAddToCart_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("9",990);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart_1.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_1.setBackground(new Color(0, 153, 255));
		btnAddToCart_1.setBounds(115, 341, 85, 21);
		panel_1_2.add(btnAddToCart_1);
		
		JPanel panel_1_3 = new JPanel();
		panel_1_3.setLayout(null);
		panel_1_3.setBackground(Color.WHITE);
		panel_1_3.setBounds(765, 123, 336, 362);
		panel_1.add(panel_1_3);
		
		JLabel lblNewLabel_3_2_3_2 = new JLabel("");
		lblNewLabel_3_2_3_2.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\sun3.jpg"));
		lblNewLabel_3_2_3_2.setBounds(47, 77, 238, 109);
		panel_1_3.add(lblNewLabel_3_2_3_2);
		
		JLabel lblNewLabel_4_1_3_2 = new JLabel("<html><pre>Soignee\r\nGreen Tinted Round Sun Glass\r\n\r\nRs.900</html></pre>");
		lblNewLabel_4_1_3_2.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_2.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_2.setBounds(24, 209, 257, 90);
		panel_1_3.add(lblNewLabel_4_1_3_2);
		
		JButton btnAddToCart_2 = new JButton("Add to Cart");
		btnAddToCart_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("10",900);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart_2.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_2.setBackground(new Color(0, 153, 255));
		btnAddToCart_2.setBounds(118, 341, 85, 21);
		panel_1_3.add(btnAddToCart_2);
		
		JPanel panel_1_4 = new JPanel();
		panel_1_4.setLayout(null);
		panel_1_4.setBackground(Color.WHITE);
		panel_1_4.setBounds(1143, 123, 336, 362);
		panel_1.add(panel_1_4);
		
		JLabel lblNewLabel_3_2_3_3 = new JLabel("");
		lblNewLabel_3_2_3_3.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\sun4.jpg"));
		lblNewLabel_3_2_3_3.setBounds(48, 77, 238, 109);
		panel_1_4.add(lblNewLabel_3_2_3_3);
		
		JLabel lblNewLabel_4_1_3_3 = new JLabel("<html><pre>Soignee\r\nGray tined Square Glass\r\n\r\nRs.990</html></pre>");
		lblNewLabel_4_1_3_3.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_3.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_3.setBounds(28, 212, 257, 90);
		panel_1_4.add(lblNewLabel_4_1_3_3);
		
		JButton btnAddToCart_3 = new JButton("Add to Cart");
		btnAddToCart_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("11",990);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart_3.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_3.setBackground(new Color(0, 153, 255));
		btnAddToCart_3.setBounds(134, 341, 85, 21);
		panel_1_4.add(btnAddToCart_3);
		panel_1.setSize(1550,1550);
		panel_1.setLayout(null);
		
		JButton btnNewButton = new JButton("2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Sunglass2 eg2 = new Sunglass2();
				dispose();
				eg2.show();	
				
			}
		});
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.setBackground(new Color(0, 153, 255));
		btnNewButton.setBounds(683, 562, 114, 40);
		panel_1.add(btnNewButton);
		
		Panel panel_2 = new Panel();
		panel_2.setLayout(null);
		panel_2.setBackground(new Color(0, 102, 204));
		panel_2.setBounds(-11, 625, 1551, 40);
		panel_1.add(panel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Copyright © 2023. All Rights Reserved");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setBounds(657, 10, 251, 25);
		panel_2.add(lblNewLabel_3);
		
		JButton btnSunGlasses = new JButton("Home");
		btnSunGlasses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main m1 =new Main(); //next page
				dispose();
				m1.show(); //next page
				
			}
			
		});
		btnSunGlasses.setFont(new Font("Sitka Heading", Font.BOLD, 13));
		btnSunGlasses.setBackground(new Color(0, 153, 255));
		btnSunGlasses.setBounds(685, 10, 124, 31);
		panel_1.add(btnSunGlasses);
		panel_1.setVisible(true);
		
	}
}
