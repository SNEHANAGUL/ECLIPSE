package frame;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JScrollBar;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.Color;
import javax.swing.UIManager;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextPane;
import javax.swing.JDesktopPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JSpinner;
import javax.swing.SpinnerListModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.JSplitPane;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JSlider;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Main extends JFrame {

	private JPanel contentPane;
	private JTextField txtCopyright;
	protected SqlQueries sqlFunctions;

	public static void main(String[] args) {
	
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					
					frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1645,1078);//Full Screen
		contentPane = new JPanel();
		SqlQueries sqlFunctions = new SqlQueries();
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 1540, 82);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel cart = new JLabel("");
		cart.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Shoppingcart sct = new Shoppingcart();
				dispose();
				sct.show();
				//dispose();
				
			}
		});
		cart.setBackground(new Color(240, 240, 240));
		cart.setBounds(1438, 10, 46, 44);
		panel.add(cart);
		cart.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\cart (1).png"));
		
		JLabel lblNewLabel_3_2_2 = new JLabel("");
		lblNewLabel_3_2_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_3_2_2.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\name1.png"));
		lblNewLabel_3_2_2.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel_3_2_2.setBounds(457, 10, 524, 62);
		panel.add(lblNewLabel_3_2_2);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\sas (1).png"));
		lblNewLabel.setBounds(26, 10, 188, 62);
		panel.add(lblNewLabel);
		
		JLabel cart_1_1 = new JLabel("login");
		cart_1_1.addMouseListener(new MouseAdapter() {
	@Override
			public void mouseClicked(MouseEvent e) {
		Login p1 = new Login();
		p1.show();
		dispose();
			}
		});
		cart_1_1.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\login.jpg"));
		cart_1_1.setBounds(1370, 10, 46, 44);
		panel.add(cart_1_1);
		
		JPanel navbar = new JPanel();
		navbar.setLayout(null);
		navbar.setBackground(UIManager.getColor("Button.background"));
		navbar.setBounds(0, 81, 1540, 36);
		contentPane.add(navbar);
		
		JButton btnEyeGlasses = new JButton("EYE GLASSES");
		btnEyeGlasses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnEyeGlasses.setFont(new Font("Sitka Heading", Font.BOLD, 13));
		btnEyeGlasses.setForeground(new Color(51, 0, 0));
		btnEyeGlasses.setBackground(new Color(0, 153, 255));
		btnEyeGlasses.setBounds(36, 10, 124, 21);
		navbar.add(btnEyeGlasses);
		
		JButton btnSunGlasses = new JButton("SUN GLASSES");
		btnSunGlasses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Sunglass1 eg2 = new Sunglass1();
				dispose();
				eg2.show();	
				
			}
		});
		btnSunGlasses.setFont(new Font("Sitka Heading", Font.BOLD, 13));
		btnSunGlasses.setBackground(new Color(0, 153, 255));
		btnSunGlasses.setBounds(269, 10, 124, 21);
		navbar.add(btnSunGlasses);
		
		JButton btnContactGlasses = new JButton("CONTACT LENSES");
		btnContactGlasses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Contactlens eg2 = new Contactlens();
				dispose();
				eg2.show();	
			
			}
		});
		btnContactGlasses.setFont(new Font("Sitka Heading", Font.BOLD, 13));
		btnContactGlasses.setBounds(502, 10, 154, 21);
		navbar.add(btnContactGlasses);
		btnContactGlasses.setBackground(new Color(0, 153, 255));
		
		JButton btnComputerGlasses = new JButton("COMPUTER GLASSES");
		btnComputerGlasses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Computer eg2 = new Computer();
				dispose();
				eg2.show();	
				
			}
		});
		btnComputerGlasses.setFont(new Font("Sitka Heading", Font.BOLD, 13));
		btnComputerGlasses.setBackground(new Color(0, 153, 255));
		btnComputerGlasses.setBounds(763, 10, 174, 21);
		navbar.add(btnComputerGlasses);
		
		JButton btnPowerGlasses = new JButton("POWER SUN GLASSES");
		btnPowerGlasses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Powersun eg2 = new Powersun();
				dispose();
				eg2.show();	
				
			}
		});
		btnPowerGlasses.setFont(new Font("Sitka Heading", Font.BOLD, 13));
		btnPowerGlasses.setBackground(new Color(0, 153, 255));
		btnPowerGlasses.setBounds(1044, 10, 180, 21);
		navbar.add(btnPowerGlasses);
		
		JButton btnReadingGlasses = new JButton("READING GLASSES");
		btnReadingGlasses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Readingglass eg2 = new Readingglass();
				dispose();
				eg2.show();	
				
			}
		});
		btnReadingGlasses.setFont(new Font("Sitka Heading", Font.BOLD, 13));
		btnReadingGlasses.setBackground(new Color(0, 153, 255));
		btnReadingGlasses.setBounds(1353, 10, 154, 21);
		navbar.add(btnReadingGlasses);
		
		JPanel footer = new JPanel();
		footer.setBackground(new Color(0, 102, 204));
		footer.setBounds(0, 690, 1540, 155);
		contentPane.add(footer);
		footer.setLayout(null);
		
		txtCopyright = new JTextField();
		txtCopyright.setBackground(new Color(0, 102, 204));
		txtCopyright.setText("Copyright © 2023. All Rights Reserved");
		txtCopyright.setBounds(430, 216, 365, 19);
		footer.add(txtCopyright);
		txtCopyright.setColumns(10);
		
		JLabel para = new JLabel("<html><pre>Eyeglasses- Shop Online from Latest Collection - SAS FRAMES.COM\r\nGone Are The Days When A Pair Of Eyeglasses Was Only Meant For Poor Vision. Today, A Pair Of Spectacles Can Redefine Your Personality, Entirely. \r\nAt SAS Frames.Com, You Will Find A Wide Range Of Specs Frames To Buy Eyeglasses Online From. From A Vast Collection Of Over 815 Pairs Of Branded Spectacles To Choose From, SAS Frames Gives You Products That Are High On Quality, Comfort As Well As Performance. The Spectacles Frame At SAS Frames.\r\nCom are Priced At A Reasonable Range To Suit Your Requirements And Come In Different Colours, Styles, Sizes And Shapes For You To Pick From. Buy Glasses Online With High Quality, Comfort, Style and Performance. Don A Pair Of Trendy Looking Eyeglasses Frames Online That Add Style and Substance To Your\r\nPersonality Instantly. With Amazing Sale And Review, You Don’t Want To Miss an Opportunity To Buy Glasses Online From Here.</html></pre>");
		para.setForeground(new Color(255, 255, 255));
		para.setFont(new Font("Malgun Gothic", Font.PLAIN, 9));
		para.setBounds(10, 10, 1520, 76);
		footer.add(para);
		
		JLabel lblNewLabel_4 = new JLabel("<html><pre>Services\r\nStore Locator\r\n\r\nEnter My Power\r\n\r\nBuying Guide\r\n\r\nFrame Size</html></pre>");
		lblNewLabel_4.setFont(new Font("Malgun Gothic", Font.BOLD, 8));
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setBounds(10, 80, 121, 95);
		footer.add(lblNewLabel_4);
		
		JLabel lblNewLabel_4_1 = new JLabel("<html><pre>About Us\r\nWe Are Hiring\r\n\r\nRefer & Earn\r\n\r\nAbout Us\r\n\r\nSAS Frames Coupons</html></pre>");
		lblNewLabel_4_1.setForeground(Color.WHITE);
		lblNewLabel_4_1.setFont(new Font("Malgun Gothic", Font.BOLD, 8));
		lblNewLabel_4_1.setBounds(141, 80, 121, 95);
		footer.add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_4_1_1 = new JLabel("<html><pre>Help\r\n\r\nFAQ's</html></pre>");
		lblNewLabel_4_1_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_1.setFont(new Font("Malgun Gothic", Font.BOLD, 8));
		lblNewLabel_4_1_1.setBounds(327, 80, 121, 43);
		footer.add(lblNewLabel_4_1_1);
		
		JLabel lblNewLabel_4_1_2 = new JLabel("<html><pre>CONNECT WITH US:\r\n\r\n08069051111\r\nsupport@sasframes.com\r\nAll Emails Will Be Answered Within 24 Hours</html></pre>");
		lblNewLabel_4_1_2.setForeground(Color.WHITE);
		lblNewLabel_4_1_2.setFont(new Font("Malgun Gothic", Font.BOLD, 8));
		lblNewLabel_4_1_2.setBounds(1296, 80, 215, 95);
		footer.add(lblNewLabel_4_1_2);
		
		JPanel Filters = new JPanel();
		Filters.setBackground(new Color(255, 255, 255));
		Filters.setBounds(0, 211, 276, 469);
		contentPane.add(Filters);
		Filters.setLayout(null);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Buy Online");
		rdbtnNewRadioButton.setFont(new Font("Tahoma", Font.PLAIN, 10));
		rdbtnNewRadioButton.setBounds(22, 83, 103, 21);
		Filters.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Try at Store");
		rdbtnNewRadioButton_1.setFont(new Font("Tahoma", Font.PLAIN, 10));
		rdbtnNewRadioButton_1.setBounds(146, 83, 103, 21);
		Filters.add(rdbtnNewRadioButton_1);
		
		JLabel lblNewLabel_3 = new JLabel("men");
		lblNewLabel_3.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\boy.jpg"));
		lblNewLabel_3.setBounds(95, 164, 49, 37);
		Filters.add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_2 = new JLabel("men");
		lblNewLabel_3_2.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\men.png"));
		lblNewLabel_3_2.setBounds(180, 170, 48, 31);
		Filters.add(lblNewLabel_3_2);
		
		JLabel lblNewLabel_3_2_1 = new JLabel("men");
		lblNewLabel_3_2_1.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\5091776.png"));
		lblNewLabel_3_2_1.setBounds(20, 164, 54, 37);
		Filters.add(lblNewLabel_3_2_1);
		
		JTextPane txtpnAvailableFrameColours = new JTextPane();
		txtpnAvailableFrameColours.setText("Available Frame Colours");
		txtpnAvailableFrameColours.setFont(new Font("Sitka Subheading", Font.BOLD, 12));
		txtpnAvailableFrameColours.setBounds(10, 255, 166, 31);
		Filters.add(txtpnAvailableFrameColours);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 0, 0));
		panel_1.setBounds(20, 298, 10, 10);
		Filters.add(panel_1);
		panel_1.setLayout(null);
		
		JPanel panel_1_2 = new JPanel();
		panel_1_2.setLayout(null);
		panel_1_2.setBackground(new Color(153, 51, 51));
		panel_1_2.setBounds(20, 346, 10, 10);
		Filters.add(panel_1_2);
		
		JPanel panel_1_3 = new JPanel();
		panel_1_3.setLayout(null);
		panel_1_3.setBackground(new Color(255, 0, 51));
		panel_1_3.setBounds(22, 387, 10, 10);
		Filters.add(panel_1_3);
		
		JPanel panel_1_2_1 = new JPanel();
		panel_1_2_1.setLayout(null);
		panel_1_2_1.setBackground(new Color(255, 204, 255));
		panel_1_2_1.setBounds(176, 298, 10, 10);
		Filters.add(panel_1_2_1);
		
		JPanel panel_1_2_2 = new JPanel();
		panel_1_2_2.setLayout(null);
		panel_1_2_2.setBackground(new Color(51, 0, 255));
		panel_1_2_2.setBounds(176, 346, 10, 10);
		Filters.add(panel_1_2_2);
		
		JPanel panel_1_2_3 = new JPanel();
		panel_1_2_3.setLayout(null);
		panel_1_2_3.setBackground(new Color(204, 204, 204));
		panel_1_2_3.setBounds(176, 387, 10, 10);
		Filters.add(panel_1_2_3);
		
		JLabel lblFilters = new JLabel("FILTERS");
		lblFilters.setFont(new Font("Sitka Heading", Font.BOLD, 14));
		lblFilters.setBounds(92, 10, 94, 25);
		Filters.add(lblFilters);
		
		JLabel lblProductOverview = new JLabel("Product Overview");
		lblProductOverview.setFont(new Font("Sitka Display", Font.BOLD, 13));
		lblProductOverview.setBounds(22, 37, 122, 25);
		Filters.add(lblProductOverview);
		
		JLabel lblShopFor = new JLabel("Shop For");
		lblShopFor.setFont(new Font("Sitka Display", Font.BOLD, 13));
		lblShopFor.setBounds(22, 129, 122, 25);
		Filters.add(lblShopFor);
		
		JLabel lblWomen = new JLabel("Women");
		lblWomen.setFont(new Font("Sitka Display", Font.BOLD, 10));
		lblWomen.setBounds(22, 203, 52, 25);
		Filters.add(lblWomen);
		
		JLabel lblKids = new JLabel("Kids");
		lblKids.setFont(new Font("Sitka Display", Font.BOLD, 10));
		lblKids.setBounds(105, 203, 52, 25);
		Filters.add(lblKids);
		
		JLabel lblMen = new JLabel("Men");
		lblMen.setFont(new Font("Sitka Display", Font.BOLD, 10));
		lblMen.setBounds(190, 203, 52, 25);
		Filters.add(lblMen);
		
		JLabel lblBlack = new JLabel("Black");
		lblBlack.setFont(new Font("Sitka Display", Font.BOLD, 13));
		lblBlack.setBounds(42, 296, 52, 25);
		Filters.add(lblBlack);
		
		JLabel lblBrown = new JLabel("Brown");
		lblBrown.setFont(new Font("Sitka Display", Font.BOLD, 13));
		lblBrown.setBounds(40, 340, 52, 25);
		Filters.add(lblBrown);
		
		JLabel lblRed = new JLabel("Red");
		lblRed.setFont(new Font("Sitka Display", Font.BOLD, 13));
		lblRed.setBounds(40, 381, 52, 25);
		Filters.add(lblRed);
		
		JLabel lblGrey = new JLabel("Grey");
		lblGrey.setFont(new Font("Sitka Display", Font.BOLD, 13));
		lblGrey.setBounds(197, 381, 52, 25);
		Filters.add(lblGrey);
		
		JLabel lblBlue = new JLabel("Blue");
		lblBlue.setFont(new Font("Sitka Display", Font.BOLD, 13));
		lblBlue.setBounds(197, 340, 52, 25);
		Filters.add(lblBlue);
		
		JLabel lblPink = new JLabel("Pink");
		lblPink.setFont(new Font("Sitka Display", Font.BOLD, 13));
		lblPink.setBounds(197, 298, 52, 21);
		Filters.add(lblPink);
		
		JPanel eye1 = new JPanel();
		eye1.setBackground(SystemColor.menu);
		eye1.setBounds(286, 211, 1254, 469);
		contentPane.add(eye1);
		eye1.setLayout(null);
		
		JButton btnNewButton = new JButton("2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Eyeglass2 e1 =new Eyeglass2();
				e1.show();
				dispose();
			}
		});
		
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 10));
		btnNewButton.setBackground(new Color(0, 153, 255));
		btnNewButton.setBounds(575, 438, 85, 21);
		eye1.add(btnNewButton);
	
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBounds(23, 49, 351, 356);
		eye1.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_3_2_3 = new JLabel("men");
		lblNewLabel_3_2_3.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\eye1.jpg"));
		lblNewLabel_3_2_3.setBounds(43, 47, 257, 195);
		panel_2.add(lblNewLabel_3_2_3);
		
		JButton btnAddToCart = new JButton("Add to Cart");
		btnAddToCart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("1",990);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart.setBackground(new Color(0, 153, 255));
		btnAddToCart.setBounds(119, 335, 85, 21);
		panel_2.add(btnAddToCart);
		
		JLabel lblNewLabel_4_1_3 = new JLabel("<html><pre>Nerdlane For Kids\r\nGlossy Black Full Frame Rectangle Glass\r\n\r\nRs.990</html></pre>");
		lblNewLabel_4_1_3.setForeground(new Color(0, 0, 0));
		lblNewLabel_4_1_3.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3.setBounds(43, 221, 257, 90);
		panel_2.add(lblNewLabel_4_1_3);
		
		JPanel panel_2_1 = new JPanel();
		panel_2_1.setBackground(Color.WHITE);
		panel_2_1.setBounds(450, 50, 351, 356);
		eye1.add(panel_2_1);
		panel_2_1.setLayout(null);
		
		JLabel lblNewLabel_3_2_3_1 = new JLabel("men");
		lblNewLabel_3_2_3_1.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\eye2.jpg"));
		lblNewLabel_3_2_3_1.setBounds(43, 47, 259, 195);
		panel_2_1.add(lblNewLabel_3_2_3_1);
		
		JButton btnAddToCart_1 = new JButton("Add to Cart");
		btnAddToCart_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("3",1190);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart_1.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_1.setBackground(new Color(0, 153, 255));
		btnAddToCart_1.setBounds(121, 334, 85, 21);
		panel_2_1.add(btnAddToCart_1);
		
		JLabel lblNewLabel_4_1_3_1 = new JLabel("<html><pre>Mirar\r\nGunMetal Full Frame Aviator Glasses\r\n\r\nRs.1190</html></pre>");
		lblNewLabel_4_1_3_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_1.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_1.setBounds(29, 219, 257, 90);
		panel_2_1.add(lblNewLabel_4_1_3_1);
		
		JPanel panel_2_2 = new JPanel();
		panel_2_2.setBackground(Color.WHITE);
		panel_2_2.setBounds(876, 49, 351, 356);
		eye1.add(panel_2_2);
		panel_2_2.setLayout(null);
		
		JLabel lblNewLabel_3_2_3_1_1 = new JLabel("men");
		lblNewLabel_3_2_3_1_1.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\eye3.jpg"));
		lblNewLabel_3_2_3_1_1.setBounds(47, 43, 257, 195);
		panel_2_2.add(lblNewLabel_3_2_3_1_1);
		
		JButton btnAddToCart_2 = new JButton("Add to Cart");
		btnAddToCart_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("4",1940);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart_2.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_2.setBackground(new Color(0, 153, 255));
		btnAddToCart_2.setBounds(142, 335, 85, 21);
		panel_2_2.add(btnAddToCart_2);
		
		JLabel lblNewLabel_4_1_3_1_1 = new JLabel("<html><pre>Vistazo\r\nPink Full Frame Glasses\r\n\r\nRs.1940</html></pre>");
		lblNewLabel_4_1_3_1_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_1_1.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_1_1.setBounds(27, 221, 257, 90);
		panel_2_2.add(lblNewLabel_4_1_3_1_1);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBounds(0, 116, 1540, 95);
		contentPane.add(lblNewLabel_1);
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\SNEHA NAGULA\\Downloads\\layerx.jpg"));
	}
}
