package frame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.Panel;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Contactlens2 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Contactlens2 frame = new Contactlens2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Contactlens2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1645,1078);
		contentPane = new JPanel();
		SqlQueries sqlFunctions = new SqlQueries();
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel contentPane_1 = new JPanel();
		contentPane_1.setLayout(null);
		contentPane_1.setBackground(new Color(204, 204, 255));
		contentPane_1.setBounds(0, 0, 1540, 845);
		contentPane.add(contentPane_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\nav.png"));
		lblNewLabel.setBounds(1158, 0, 382, 181);
		contentPane_1.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 1175, 181);
		contentPane_1.add(panel);
		
		JLabel logo = new JLabel("");
		logo.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\name1.png"));
		logo.setForeground(new Color(0, 102, 204));
		logo.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 66));
		logo.setBounds(28, 10, 518, 143);
		panel.add(logo);
		
		JLabel lblNewLabel_2 = new JLabel("<html><pre>Discover the luxury of internationally appealing, premium designs with John Jacobs\r\nCollections. These bring back iconic elements from history and merge them together with \r\nthe modish craftsmanship of today to get the very best on your eyes. Experience the \r\nopulence of owning a style statement with its most popular collections.</html></pre>");
		lblNewLabel_2.setBounds(586, 28, 531, 108);
		panel.add(lblNewLabel_2);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(21, 280, 336, 317);
		contentPane_1.add(panel_1);
		
		JLabel lblNewLabel_3_2_3 = new JLabel("");
		lblNewLabel_3_2_3.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\contact5.jpg"));
		lblNewLabel_3_2_3.setBounds(35, 69, 238, 109);
		panel_1.add(lblNewLabel_3_2_3);
		
		JLabel lblNewLabel_4_1_3 = new JLabel("<html><pre>Freshlook(Gray)\r\nUsage 1 Month, 2 Lenses\r\n\r\nRs.749</html></pre>");
		lblNewLabel_4_1_3.setForeground(Color.BLACK);
		lblNewLabel_4_1_3.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3.setBounds(28, 196, 257, 90);
		panel_1.add(lblNewLabel_4_1_3);
		
		JButton btnAddToCart = new JButton("Add to Cart");
		btnAddToCart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("20",749);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart.setBackground(new Color(0, 153, 255));
		btnAddToCart.setBounds(107, 296, 85, 21);
		panel_1.add(btnAddToCart);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setLayout(null);
		panel_1_1.setBackground(Color.WHITE);
		panel_1_1.setBounds(381, 280, 367, 317);
		contentPane_1.add(panel_1_1);
		
		JLabel lblNewLabel_3_2_3_1 = new JLabel("");
		lblNewLabel_3_2_3_1.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\contact6.jpg"));
		lblNewLabel_3_2_3_1.setBounds(53, 75, 231, 125);
		panel_1_1.add(lblNewLabel_3_2_3_1);
		
		JLabel lblNewLabel_4_1_3_1 = new JLabel("<html><pre>Freshlook(Ahethyst)\r\nUsage 1 Month, 2 Lenses\r\n\r\nRs.749</html></pre>");
		lblNewLabel_4_1_3_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_1.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_1.setBounds(27, 200, 257, 90);
		panel_1_1.add(lblNewLabel_4_1_3_1);
		
		JButton btnAddToCart_1 = new JButton("Add to Cart");
		btnAddToCart_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("21",749);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart_1.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_1.setBackground(new Color(0, 153, 255));
		btnAddToCart_1.setBounds(138, 296, 85, 21);
		panel_1_1.add(btnAddToCart_1);
		
		JPanel panel_1_2 = new JPanel();
		panel_1_2.setLayout(null);
		panel_1_2.setBackground(Color.WHITE);
		panel_1_2.setBounds(771, 280, 367, 317);
		contentPane_1.add(panel_1_2);
		
		JLabel lblNewLabel_3_2_3_2 = new JLabel("");
		lblNewLabel_3_2_3_2.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\contact7.jpg"));
		lblNewLabel_3_2_3_2.setBounds(48, 68, 275, 144);
		panel_1_2.add(lblNewLabel_3_2_3_2);
		
		JLabel lblNewLabel_4_1_3_2 = new JLabel("<html><pre>Freshlook(Blue)\r\nUsage 1 Month, 2 Lenses\r\n\r\nRs.749</html></pre>");
		lblNewLabel_4_1_3_2.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_2.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_2.setBounds(36, 204, 301, 90);
		panel_1_2.add(lblNewLabel_4_1_3_2);
		
		JButton btnAddToCart_2 = new JButton("Add to Cart");
		btnAddToCart_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("22",749);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart_2.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_2.setBackground(new Color(0, 153, 255));
		btnAddToCart_2.setBounds(143, 296, 85, 21);
		panel_1_2.add(btnAddToCart_2);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Contactlens m1 =new Contactlens(); //next page
				dispose();
				m1.show(); //next page
				
			}
		});
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.setBackground(new Color(0, 153, 255));
		btnNewButton.setBounds(689, 698, 114, 40);
		contentPane_1.add(btnNewButton);
		
		Panel panel_2 = new Panel();
		panel_2.setLayout(null);
		panel_2.setBackground(new Color(0, 102, 204));
		panel_2.setBounds(0, 805, 1551, 40);
		contentPane_1.add(panel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Copyright © 2023. All Rights Reserved");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setBounds(657, 10, 251, 25);
		panel_2.add(lblNewLabel_3);
		
		JPanel panel_1_2_1 = new JPanel();
		panel_1_2_1.setLayout(null);
		panel_1_2_1.setBackground(Color.WHITE);
		panel_1_2_1.setBounds(1158, 280, 353, 317);
		contentPane_1.add(panel_1_2_1);
		
		JLabel lblNewLabel_3_2_3_2_1 = new JLabel("");
		lblNewLabel_3_2_3_2_1.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\contact8.jpg"));
		lblNewLabel_3_2_3_2_1.setBounds(46, 80, 275, 120);
		panel_1_2_1.add(lblNewLabel_3_2_3_2_1);
		
		JLabel lblNewLabel_4_1_3_2_1 = new JLabel("<html><pre>Freshlook(Brilliant Blue)\r\nUsage 1 Month, 2 Lenses\r\n\r\nRs.749</html></pre>");
		lblNewLabel_4_1_3_2_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_2_1.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_2_1.setBounds(36, 196, 275, 90);
		panel_1_2_1.add(lblNewLabel_4_1_3_2_1);
		
		JButton btnAddToCart_2_1 = new JButton("Add to Cart");
		btnAddToCart_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("23",749);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart_2_1.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_2_1.setBackground(new Color(0, 153, 255));
		btnAddToCart_2_1.setBounds(139, 296, 85, 21);
		panel_1_2_1.add(btnAddToCart_2_1);
		
		JLabel lblNewLabel_3_2_3_2_2 = new JLabel("");
		lblNewLabel_3_2_3_2_2.setBounds(36, 50, 275, 144);
		panel_1_2_1.add(lblNewLabel_3_2_3_2_2);
	}

}
