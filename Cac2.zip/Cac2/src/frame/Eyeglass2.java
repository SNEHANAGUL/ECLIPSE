package frame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JOptionPane;

import java.awt.Canvas;
import java.awt.Panel;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Eyeglass2 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Eyeglass2 frame = new Eyeglass2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Eyeglass2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1645,1078);//Full Screen
		contentPane = new JPanel();
		contentPane.setBackground(new Color(204, 204, 255));
		SqlQueries sqlFunctions = new SqlQueries();
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\nav.png"));
		lblNewLabel.setBounds(1158, 0, 382, 181);
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 1175, 181);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel logo = new JLabel("");
		logo.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\name1.png"));
		logo.setForeground(new Color(0, 102, 204));
		logo.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 66));
		logo.setBounds(28, 10, 518, 143);
		panel.add(logo);
		
		JLabel lblNewLabel_2 = new JLabel("<html><pre>Discover the luxury of internationally appealing, premium designs with John Jacobs\r\nCollections. These bring back iconic elements from history and merge them together with \r\nthe modish craftsmanship of today to get the very best on your eyes. Experience the \r\nopulence of owning a style statement with its most popular collections.</html></pre>");
		lblNewLabel_2.setBounds(586, 28, 531, 108);
		panel.add(lblNewLabel_2);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(21, 280, 336, 317);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_3_2_3 = new JLabel("");
		lblNewLabel_3_2_3.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\eye4.jpg"));
		lblNewLabel_3_2_3.setBounds(35, 69, 238, 109);
		panel_1.add(lblNewLabel_3_2_3);
		
		JLabel lblNewLabel_4_1_3 = new JLabel("<html><pre>NerdLane\r\nBlack Full Frame Eye Glass\r\n\r\nRs.1120</html></pre>");
		lblNewLabel_4_1_3.setForeground(Color.BLACK);
		lblNewLabel_4_1_3.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3.setBounds(28, 196, 257, 90);
		panel_1.add(lblNewLabel_4_1_3);
		
		JButton btnAddToCart = new JButton("Add to Cart");
			btnAddToCart.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(globals.SESSION_USERID!="")
					{
						sqlFunctions.insertCartItem("5",1120);
						JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
					}
					else
					{
						JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
						 Login second = new Login();  
			                second.show();
			                dispose();
					}
					
				}
		});
		btnAddToCart.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart.setBackground(new Color(0, 153, 255));
		btnAddToCart.setBounds(107, 296, 85, 21);
		panel_1.add(btnAddToCart);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setBackground(Color.WHITE);
		panel_1_1.setBounds(381, 280, 367, 317);
		contentPane.add(panel_1_1);
		panel_1_1.setLayout(null);
		
		JLabel lblNewLabel_3_2_3_1 = new JLabel("");
		lblNewLabel_3_2_3_1.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\eye5.jpg"));
		lblNewLabel_3_2_3_1.setBounds(53, 75, 231, 125);
		panel_1_1.add(lblNewLabel_3_2_3_1);
		
		JLabel lblNewLabel_4_1_3_1 = new JLabel("<html><pre>Viztazo\r\nTransparent Full Frame Butterfly Glass\r\n\r\nRs.1200</html></pre>");
		lblNewLabel_4_1_3_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_1.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_1.setBounds(27, 200, 257, 90);
		panel_1_1.add(lblNewLabel_4_1_3_1);
		
		JButton btnAddToCart_1 = new JButton("Add to Cart");
		btnAddToCart_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("6",1200);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart_1.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_1.setBackground(new Color(0, 153, 255));
		btnAddToCart_1.setBounds(138, 296, 85, 21);
		panel_1_1.add(btnAddToCart_1);
		
		JPanel panel_1_2 = new JPanel();
		panel_1_2.setBackground(Color.WHITE);
		panel_1_2.setBounds(771, 280, 367, 317);
		contentPane.add(panel_1_2);
		panel_1_2.setLayout(null);
		
		JLabel lblNewLabel_3_2_3_2 = new JLabel("");
		lblNewLabel_3_2_3_2.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\eye6.jpg"));
		lblNewLabel_3_2_3_2.setBounds(48, 68, 275, 144);
		panel_1_2.add(lblNewLabel_3_2_3_2);
		
		JLabel lblNewLabel_4_1_3_2 = new JLabel("<html><pre>Mirzaro\r\nGrey Full Frame Rectangle Glass\r\n\r\nRs.1990</html></pre>");
		lblNewLabel_4_1_3_2.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_2.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_2.setBounds(36, 204, 257, 90);
		panel_1_2.add(lblNewLabel_4_1_3_2);
		
		JButton btnAddToCart_2 = new JButton("Add to Cart");
		btnAddToCart_2.setBounds(143, 296, 85, 21);
		panel_1_2.add(btnAddToCart_2);
			btnAddToCart_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(globals.SESSION_USERID!="")
					{
						sqlFunctions.insertCartItem("7",1990);
						JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
					}
					else
					{
						JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
						 Login second = new Login();  
			                second.show();
			                dispose();
					}
					
				}
		});
		btnAddToCart_2.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_2.setBackground(new Color(0, 153, 255));
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { //next page
				Main m1 =new Main(); //next page
				dispose();
				m1.show(); //next page
				 //next page
			}
		});
		btnNewButton.setBackground(new Color(0, 153, 255));
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.setBounds(689, 698, 114, 40);
		contentPane.add(btnNewButton);
		
		Panel panel_2 = new Panel();
		panel_2.setBackground(new Color(0, 102, 204));
		panel_2.setBounds(0, 805, 1551, 40);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("Copyright © 2023. All Rights Reserved");
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setBounds(657, 10, 251, 25);
		panel_2.add(lblNewLabel_3);
		
		JPanel panel_1_2_1 = new JPanel();
		panel_1_2_1.setLayout(null);
		panel_1_2_1.setBackground(Color.WHITE);
		panel_1_2_1.setBounds(1158, 280, 353, 317);
		contentPane.add(panel_1_2_1);
		
		JLabel lblNewLabel_3_2_3_2_1 = new JLabel("");
		lblNewLabel_3_2_3_2_1.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\eye7.jpg"));
		lblNewLabel_3_2_3_2_1.setBounds(46, 80, 275, 120);
		panel_1_2_1.add(lblNewLabel_3_2_3_2_1);
		
		JLabel lblNewLabel_4_1_3_2_1 = new JLabel("<html><pre>Nerdlane\r\nFloral Full Frame Cateye Glasses\r\n\r\nRs.990</html></pre>");
		lblNewLabel_4_1_3_2_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_2_1.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_2_1.setBounds(36, 206, 257, 90);
		panel_1_2_1.add(lblNewLabel_4_1_3_2_1);
		
		JButton btnAddToCart_2_1 = new JButton("Add to Cart");
			btnAddToCart_2_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(globals.SESSION_USERID!="")
					{
						sqlFunctions.insertCartItem("49",990);
						JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
					}
					else
					{
						JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
						 Login second = new Login();  
			                second.show();
			                dispose();
					}
					
				}
		});
		btnAddToCart_2_1.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_2_1.setBackground(new Color(0, 153, 255));
		btnAddToCart_2_1.setBounds(139, 296, 85, 21);
		panel_1_2_1.add(btnAddToCart_2_1);
		
		JLabel lblNewLabel_3_2_3_2_2 = new JLabel("");
		lblNewLabel_3_2_3_2_2.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\sun7.jpg"));
		lblNewLabel_3_2_3_2_2.setBounds(36, 50, 275, 144);
		panel_1_2_1.add(lblNewLabel_3_2_3_2_2);
	}
}
