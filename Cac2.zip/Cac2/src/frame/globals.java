package frame;

public class globals {
	public static String SESSION_USERID = "";
    public static String SESSION_USERNAME = "";
    public static String SESSION_PASSWORD = "";
    
}
