package frame;

import java.awt.EventQueue;
import java.awt.Image;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Purchase extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Purchase frame = new Purchase();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Purchase() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1645,1078);//Full Screen
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		Connection connection = dbconnection.getConnection();
		JLabel address = new JLabel("");
		address.setFont(new Font("Microsoft Himalaya", Font.BOLD, 23));
		address.setBounds(561, 177, 317, 44);
		contentPane.add(address);
		JLabel name = new JLabel("");
		name.setFont(new Font("Microsoft Himalaya", Font.BOLD, 25));
		name.setBounds(561, 82, 376, 44);
		contentPane.add(name);
		try {
			ResultSet resultSet = connection.createStatement().executeQuery("select * from users where id = "+globals.SESSION_USERID);
			 while (resultSet.next()) {
				 name.setText("Hello "+resultSet.getString(2));
				 address.setText("Delivered To : "+resultSet.getString(5));
			    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		JLabel qtyamount = new JLabel("");
		qtyamount.setFont(new Font("Microsoft Himalaya", Font.BOLD, 24));
		qtyamount.setBounds(571, 207, 728, 138);
		contentPane.add(qtyamount);
		
		
		
		JLabel lblNewLabel_2 = new JLabel("Your Order is on the Way");
		lblNewLabel_2.setFont(new Font("Microsoft Himalaya", Font.BOLD | Font.ITALIC, 31));
		lblNewLabel_2.setBounds(82, 61, 376, 44);
		contentPane.add(lblNewLabel_2);
		
	
		
		ImageIcon imageIcon1 = new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\done.jpg");
        Image image1 = imageIcon1.getImage(); // transform it

        Image newimg1 = image1.getScaledInstance(1540, 808, java.awt.Image.SCALE_SMOOTH); // scale it the smooth way

        imageIcon1 = new ImageIcon(newimg1);
        
        JButton btnClose = new JButton("CLOSE");
        btnClose.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Thankyou e1 =new Thankyou();
				e1.show();
				dispose();
        	
        	}
        });
        btnClose.setForeground(new Color(0, 204, 255));
        btnClose.setFont(new Font("Javanese Text", Font.BOLD, 15));
        btnClose.setBackground(new Color(53, 19, 107));
        btnClose.setBounds(43, 759, 117, 29);
        contentPane.add(btnClose);
        
        JButton btnHome = new JButton("HOME");
        btnHome.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Main e1 =new Main();
				e1.show();
				dispose();
        		
        	}
        });
        btnHome.setForeground(new Color(0, 204, 255));
        btnHome.setFont(new Font("Javanese Text", Font.BOLD, 15));
        btnHome.setBackground(new Color(53, 19, 107));
        btnHome.setBounds(1399, 761, 117, 29);
        contentPane.add(btnHome);
        
        JLabel lastpic = new JLabel("");
		lastpic.setIcon(imageIcon1);
		lastpic.setBounds(0, -26, 1540, 871);
		contentPane.add(lastpic);
		
		try {
			String query = "select sum(c.qty), sum(c.qty*c.amt) from cart c inner join users u on u.id=c.user_id where c.user_id=u.id and u.id=?";
			PreparedStatement statement1 = connection.prepareStatement(query);
			 statement1.setString(1, globals.SESSION_USERID);
			 ResultSet resultSet = statement1.executeQuery();
			 while (resultSet.next()) {
				 qtyamount.setText("Quantity = "+resultSet.getString(1)+"     Total Amount = "+resultSet.getString(2));
			    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
