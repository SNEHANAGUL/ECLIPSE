package frame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JScrollBar;
import java.awt.Panel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Powersun extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Powersun frame = new Powersun();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Powersun() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1645,1078);//Full Screen
		contentPane = new JPanel();
		SqlQueries sqlFunctions = new SqlQueries();
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 1159, 190);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel text = new JLabel("<html><pre>Discover the luxury of internationally appealing, premium designs with John Jacobs\r\nCollections. These bring back iconic elements from history and merge them together with \r\nthe modish craftsmanship of today to get the very best on your eyes. Experience the \r\nopulence of owning a style statement with its most popular collections.</html></pre>");
		text.setBounds(578, 36, 541, 120);
		panel.add(text);
		
		JLabel logo = new JLabel("");
		logo.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\name1.png"));
		logo.setBounds(31, 36, 514, 133);
		panel.add(logo);
		
		JLabel pic = new JLabel("");
		pic.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\nav.png"));
		pic.setBounds(1158, 0, 382, 190);
		contentPane.add(pic);
		
		JPanel violet = new JPanel();
		violet.setBackground(new Color(204, 204, 255));
		violet.setBounds(10, 200, 1540, 653);
		contentPane.add(violet);
		violet.setLayout(null);
		
		JPanel panel_1_1_1_1 = new JPanel();
		panel_1_1_1_1.setLayout(null);
		panel_1_1_1_1.setBackground(Color.WHITE);
		panel_1_1_1_1.setBounds(31, 108, 336, 317);
		violet.add(panel_1_1_1_1);
		
		JLabel lblNewLabel_3_2_3_1_1 = new JLabel("");
		lblNewLabel_3_2_3_1_1.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\powersun1.jpg"));
		lblNewLabel_3_2_3_1_1.setBounds(28, 79, 257, 109);
		panel_1_1_1_1.add(lblNewLabel_3_2_3_1_1);
		
		JLabel lblNewLabel_4_1_3_1_1 = new JLabel("<html><pre>Alf\r\nGold Tinted Cateye Prescription Sunglasses\r\n\r\nRs.1999</html></pre>");
		lblNewLabel_4_1_3_1_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_1_1.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_1_1.setBounds(28, 196, 257, 90);
		panel_1_1_1_1.add(lblNewLabel_4_1_3_1_1);
		
		JButton btnAddToCart_1_1 = new JButton("Add to Cart");
		btnAddToCart_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("32",1999);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart_1_1.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_1_1.setBackground(new Color(0, 153, 255));
		btnAddToCart_1_1.setBounds(107, 296, 85, 21);
		panel_1_1_1_1.add(btnAddToCart_1_1);
		
		JPanel panel_1_1_1_1_1 = new JPanel();
		panel_1_1_1_1_1.setLayout(null);
		panel_1_1_1_1_1.setBackground(Color.WHITE);
		panel_1_1_1_1_1.setBounds(412, 108, 336, 317);
		violet.add(panel_1_1_1_1_1);
		
		JLabel lblNewLabel_3_2_3_1_1_1 = new JLabel("");
		lblNewLabel_3_2_3_1_1_1.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\poersun2.jpg"));
		lblNewLabel_3_2_3_1_1_1.setBounds(28, 77, 257, 109);
		panel_1_1_1_1_1.add(lblNewLabel_3_2_3_1_1_1);
		
		JLabel lblNewLabel_4_1_3_1_1_1 = new JLabel("<html><pre>Alf\r\nGold Tinted Cateye Prescription Sunglass\r\n\r\nRs.1999</html></pre>");
		lblNewLabel_4_1_3_1_1_1.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_1_1_1.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_1_1_1.setBounds(28, 196, 257, 90);
		panel_1_1_1_1_1.add(lblNewLabel_4_1_3_1_1_1);
		
		JButton btnAddToCart_1_1_1 = new JButton("Add to Cart");
		btnAddToCart_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("42",1999);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart_1_1_1.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_1_1_1.setBackground(new Color(0, 153, 255));
		btnAddToCart_1_1_1.setBounds(107, 296, 85, 21);
		panel_1_1_1_1_1.add(btnAddToCart_1_1_1);
		
		JPanel panel_1_1_1_1_2 = new JPanel();
		panel_1_1_1_1_2.setLayout(null);
		panel_1_1_1_1_2.setBackground(Color.WHITE);
		panel_1_1_1_1_2.setBounds(785, 108, 336, 317);
		violet.add(panel_1_1_1_1_2);
		
		JLabel lblNewLabel_3_2_3_1_1_2 = new JLabel("");
		lblNewLabel_3_2_3_1_1_2.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\powersun3.jpg"));
		lblNewLabel_3_2_3_1_1_2.setBounds(28, 77, 257, 109);
		panel_1_1_1_1_2.add(lblNewLabel_3_2_3_1_1_2);
		
		JLabel lblNewLabel_4_1_3_1_1_2 = new JLabel("<html><pre>Alf\r\nTortoise Tinted Wayfarer Prescription Sunglasses\r\n\r\nRs.1999</html></pre>");
		lblNewLabel_4_1_3_1_1_2.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_1_1_2.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_1_1_2.setBounds(28, 196, 286, 90);
		panel_1_1_1_1_2.add(lblNewLabel_4_1_3_1_1_2);
		
		JButton btnAddToCart_1_1_2 = new JButton("Add to Cart");
		btnAddToCart_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("43",1999);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart_1_1_2.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_1_1_2.setBackground(new Color(0, 153, 255));
		btnAddToCart_1_1_2.setBounds(107, 296, 85, 21);
		panel_1_1_1_1_2.add(btnAddToCart_1_1_2);
		
		JPanel panel_1_1_1_1_3 = new JPanel();
		panel_1_1_1_1_3.setLayout(null);
		panel_1_1_1_1_3.setBackground(Color.WHITE);
		panel_1_1_1_1_3.setBounds(1155, 108, 336, 317);
		violet.add(panel_1_1_1_1_3);
		
		JLabel lblNewLabel_3_2_3_1_1_3 = new JLabel("");
		lblNewLabel_3_2_3_1_1_3.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\powersun4.jpg"));
		lblNewLabel_3_2_3_1_1_3.setBounds(28, 77, 257, 109);
		panel_1_1_1_1_3.add(lblNewLabel_3_2_3_1_1_3);
		
		JLabel lblNewLabel_4_1_3_1_1_3 = new JLabel("<html><pre>Alf\r\nBrown Tinted Wayfarer Prescription Sunglasses\r\n\r\nRs.1890</html></pre>");
		lblNewLabel_4_1_3_1_1_3.setForeground(Color.BLACK);
		lblNewLabel_4_1_3_1_1_3.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
		lblNewLabel_4_1_3_1_1_3.setBounds(28, 196, 275, 90);
		panel_1_1_1_1_3.add(lblNewLabel_4_1_3_1_1_3);
		
		JButton btnAddToCart_1_1_3 = new JButton("Add to Cart");
		btnAddToCart_1_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(globals.SESSION_USERID!="")
				{
					sqlFunctions.insertCartItem("44",1890);
					JOptionPane.showMessageDialog(contentPane, "Item Successfully Added to Cart!");
				}
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Login Before Adding to Cart");
					 Login second = new Login();  
		                second.show();
		                dispose();
				}
				
			}
		});
		btnAddToCart_1_1_3.setFont(new Font("Sitka Text", Font.BOLD, 9));
		btnAddToCart_1_1_3.setBackground(new Color(0, 153, 255));
		btnAddToCart_1_1_3.setBounds(128, 296, 85, 21);
		panel_1_1_1_1_3.add(btnAddToCart_1_1_3);
		
		JButton btnNewButton = new JButton("2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Powersun2 eg2 = new Powersun2();
				eg2.show();	
				dispose();
			}
		});
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.setBackground(new Color(0, 153, 255));
		btnNewButton.setBounds(701, 502, 114, 40);
		violet.add(btnNewButton);
		
		Panel panel_2 = new Panel();
		panel_2.setLayout(null);
		panel_2.setBackground(new Color(0, 102, 204));
		panel_2.setBounds(0, 613, 1540, 40);
		violet.add(panel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Copyright © 2023. All Rights Reserved");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setBounds(657, 10, 251, 25);
		panel_2.add(lblNewLabel_3);
		
		JButton btnPowerGlasses = new JButton("Home");
		btnPowerGlasses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main m1 =new Main(); //next page
				m1.show(); //next page
				dispose(); //next page
			}
		});
		btnPowerGlasses.setFont(new Font("Sitka Heading", Font.BOLD, 13));
		btnPowerGlasses.setBackground(new Color(0, 153, 255));
		btnPowerGlasses.setBounds(688, 10, 161, 21);
		violet.add(btnPowerGlasses);
		

	}

}
