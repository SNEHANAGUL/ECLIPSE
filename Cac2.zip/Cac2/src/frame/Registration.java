package frame;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;

public class Registration extends JFrame {

    private JPanel contentPane;
    private JTextField emailField;
    private JPasswordField passw;
    private JTextField loginEmailField;
    private JPasswordField loginPasswordField;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Registration frame = new Registration();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Registration() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1645,1078);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(255, 255, 255));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
       
        JPanel panel = new JPanel();
        panel.setBackground(new Color(102, 153, 255));
        panel.setBounds(586, 72, 440, 471);
        contentPane.add(panel);
                panel.setLayout(null);
       
        JLabel lblNewLabel_2 = new JLabel("REGISTRATION");
        lblNewLabel_2.setForeground(new Color(255, 255, 255));
        lblNewLabel_2.setBounds(128, 31, 191, 30);
        panel.add(lblNewLabel_2);
        lblNewLabel_2.setFont(new Font("Microsoft Himalaya", Font.BOLD, 34));
               
                        JLabel emailLabel = new JLabel("Username ");
                        emailLabel.setForeground(new Color(255, 255, 255));
                        emailLabel.setBounds(37, 107, 97, 16);
                        panel.add(emailLabel);
                        emailLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 15));
                       
                                emailField = new JTextField();
                                emailField.setBounds(209, 106, 198, 26);
                                panel.add(emailField);
                                emailField.setColumns(10);
                               
                                        JLabel passwordLabel = new JLabel("Password");
                                        passwordLabel.setForeground(new Color(255, 255, 255));
                                        passwordLabel.setBounds(37, 307, 130, 16);
                                        panel.add(passwordLabel);
                                        passwordLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 15));
                                       
                                                passw = new JPasswordField();
                                                passw.setBounds(209, 306, 198, 26);
                                                panel.add(passw);
                                               
                                                        JButton registerButton = new JButton("Register");
                                                        registerButton.setBounds(163, 374, 117, 29);
                                                        panel.add(registerButton);
                                                        registerButton.setFont(new Font("Javanese Text", Font.BOLD, 15));
                                                       
                                                        textField = new JTextField();
                                                        textField.setColumns(10);
                                                        textField.setBounds(209, 156, 198, 26);
                                                        panel.add(textField);
                                                       
                                                        textField_1 = new JTextField();
                                                        textField_1.setColumns(10);
                                                        textField_1.setBounds(209, 204, 198, 26);
                                                        panel.add(textField_1);
                                                       
                                                        textField_2 = new JTextField();
                                                        textField_2.setColumns(10);
                                                        textField_2.setBounds(209, 257, 198, 26);
                                                        panel.add(textField_2);
                                                       
                                                        JLabel lblNewLabel_3 = new JLabel("Contact Number");
                                                        lblNewLabel_3.setForeground(new Color(255, 255, 255));
                                                        lblNewLabel_3.setFont(new Font("Malgun Gothic", Font.BOLD, 15));
                                                        lblNewLabel_3.setBounds(37, 155, 130, 20);
                                                        panel.add(lblNewLabel_3);
                                                       
                                                        JLabel lblNewLabel_4 = new JLabel("Address");
                                                        lblNewLabel_4.setForeground(new Color(255, 255, 255));
                                                        lblNewLabel_4.setFont(new Font("Malgun Gothic", Font.BOLD, 15));
                                                        lblNewLabel_4.setBounds(37, 202, 117, 23);
                                                        panel.add(lblNewLabel_4);
                                                       
                                                        JLabel lblNewLabel_5 = new JLabel("State");
                                                        lblNewLabel_5.setForeground(new Color(255, 255, 255));
                                                        lblNewLabel_5.setFont(new Font("Malgun Gothic", Font.BOLD, 15));
                                                        lblNewLabel_5.setBounds(37, 254, 131, 24);
                                                        panel.add(lblNewLabel_5);
                                                                                                
                                                                                                
                                                                                                ImageIcon imageIcon1 = new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\bg.jpg");
                                                                                                Image image1 = imageIcon1.getImage(); // transform it

                                                                                                Image newimg1 = image1.getScaledInstance(1553, 870, java.awt.Image.SCALE_SMOOTH); // scale it the smooth way

                                                                                                imageIcon1 = new ImageIcon(newimg1);
                                                                                                
                                                                                                JLabel lblNewLabel = new JLabel("");
                                                                                                lblNewLabel.setIcon(new ImageIcon("D:\\Christ\\Sem 3\\Java\\cac2\\sas.png"));
                                                                                                lblNewLabel.setBounds(10, 10, 510, 89);
                                                                                                contentPane.add(lblNewLabel);
                                                                                                
                                                                                                JLabel bg = new JLabel("");
                                                                                                bg.setIcon(imageIcon1);
                                                                                                bg.setBounds(-1, 0, 1553, 845);
                                                                                                contentPane.add(bg);
                                                                                          
                                                        registerButton.addActionListener(new ActionListener() {
                                                            public void actionPerformed(ActionEvent e) {
                                                                
															
																String uname = emailField.getText();
																String cnum = textField.getText();
																String addr = textField_1.getText();
                                                                String state = textField_2.getText();
                                                                String pass = String.valueOf(passw.getPassword());
                                                                register(uname, cnum, addr,pass);
                                                            }
                                                        });
    }

    private void register(String uname, String cnum, String addr,String pass) {
        String query = "INSERT INTO users (uname,cnum,addr, pass) VALUES (?,?,?,?)";
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sasFrames", "root", "");
                PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, uname);
            statement.setString(2, cnum);
            statement.setString(3, addr);
            statement.setString(4, pass);
          
            int rows = statement.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(contentPane, "Registration successful!");
                Login second = new Login();  
                second.show();
                dispose();
     //  setVisible(false); // Hide current frame
       //second.getItems(cart,index);
      // second.setVisible(true); //second frame
            } else {
                JOptionPane.showMessageDialog(contentPane, "Registration failed!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}